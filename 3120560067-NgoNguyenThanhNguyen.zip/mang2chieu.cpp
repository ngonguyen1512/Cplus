#include<iostream>
using namespace std;
const int dong=100;
const int cot=100;
void nhaps(int &n, int &m) {
    cout<<"Nhap n = "; cin>>n; //n la dong
    cout<<"Nhap m = "; cin>>m; //m la cot
}
void nhapm(int a[][cot], int n, int m) { 
    cout<<"Nhap gia tri mang: "<<endl;
    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++)
            cin>>a[i][j];
}
void xuatm(int a[][cot], int n, int m) {
    cout<<"Mang"<<endl;
    for(int i=0; i<n; i++) {
        for(int j=0; j<m; j++) 
            cout<<" "<<a[i][j];
        cout<<" "<<endl;
    }
}
int dcheochinh(int a[][cot], int n, int m) {
    int sum=0;
    for (int i = 0; i < n; i++) 
      for (int j = 0; j < m; j++) 
         if (i == j)
            sum = sum + a[i][j];
   return sum;
}
int dcheophu(int a[][cot],int n, int m)// tong duong cheo phu
{
	int tong=0;
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			if(j==n-i-1)
				tong+=a[i][j];
	return tong;
}

void ChuyenMang(int a[][100], int m, int n, int B[], int &p)
{
    p = m*n;    //p là số phần tử của mảng B
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            B[i*n + j] = a[i][j];
}
void SapXep1Chieu(int a[], int n)
{
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (a[i] > a[j])
            {
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
}
void ZicZacXeo(int a[][cot], int n, int m)
{
    int B[100];
    int p;
    ChuyenMang(a,m,n,B,p);
    SapXep1Chieu(B,p);
    int vt = 0;
    int trai, phai;
    trai = 1;
    phai = 1;
    int i = 0, j = 0;
    a[i][j] = B[vt++];
    do {
        if (j == n - 1)
            i++;
        else
            j++;
        a[i][j] = B[vt++];
        cout<<"A["<<i<<"]["<<j<<"]= "<<a[i][j];
        while (i < m - 1 && j > 0) {
            i++;
            j--;
            a[i][j] = B[vt++];
            cout<<"a["<<i<<"]["<<j<<"]= "<<a[i][j];
        }
        if (i == m - 1)
            j++;
        else
            i++;
        a[i][j] = B[vt++];
        cout<<"a["<<i<<"]["<<j<<"]= "<<a[i][j];
        while (i > 0 && j < n - 1) {
            i--;
            j++;
            a[i][j] = B[vt++];
            cout<<"a["<<i<<"]["<<j<<"]= "<<a[i][j];
        }
    } while (i < m - 1 || j < n - 1);
}
int main() {
    int n,m;
    int a[dong][cot];
    nhaps(n,m);
    nhapm(a,n,m);
    xuatm(a,n,m);
    cout<<"Tong duong cheo chinh la: "<<dcheochinh(a,n,m)<<endl;
    cout<<"Tong duong cheo phu la: "<<dcheophu(a,n,m)<<endl;
    // XuLy(a,n,m);
    // xuatm(a,n,m);
    ZicZacXeo(a,n,m);
    xuatm(a,n,m);
    return 0;
}