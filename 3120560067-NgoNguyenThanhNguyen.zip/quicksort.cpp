#include <iostream>
#include <cmath>
using namespace std;

void nhap(int a[], int &n) { 
    cout<<"Nhap kich thuoc mang n = "; cin>>n;
    cout<<"Nhap gia tri mang"<<endl;
    for(int i=0; i<n; i++) { 
        cin>>a[i];
    }
}

void xuat(int a[], int &n) { 
    for(int i=0; i<n; i++) { 
        cout<<" "<<a[i];
    }
}

void swap(int &x, int &y)
{
    int temp = x;
    x = y;
    y = temp;
} 

/*
            9 | -3 | 5 |2 | 6 | 8 | -6 | 1 | 3
      <=3     /                           \   >=3
     -3 | 2 | -6 | 1        3         8 | 5 | 9 | 6
 <=1 /          \ >=1              <=6 /        \ >=6
 -3 | -6   1     2                    5    6   9 | 8
  /   \ >=-6                                    / \>=8
 -6   -3                                       8   9
*/
int partition (int arr[], int low, int high)
{
    int pivot = arr[high];    // chọn phần tử lớn nhất làm chốt
    int left = low; //left là vị trí đầu
    int right = high - 1; // right là vị trí sau pivot
    while(true){
        while(left <= right && arr[left] < pivot) 
            left++; // Tìm phần tử >= arr[pivot]
        while(right >= left && arr[right] > pivot)      
            right--; // Tìm phần tử <= arr[pivot]
        if (left >= right) 
            break; // Đã duyệt xong thì thoát vòng lặp
        swap(&arr[left], &arr[right]); // Nếu chưa xong, đổi chỗ.
        left++; // Vì left hiện tại đã xét, nên cần tăng
        right--; // Vì right hiện tại đã xét, nên cần giảm
    }
    swap(&arr[left], &arr[high]);
    return left; // Trả về chỉ số sẽ dùng để chia đổi mảng
}

void quickSort(int arr[], int low, int high)
{
    if (low < high) {
        /* p là chỉ số nơi phần tử này đã đứng đúng vị trí
         và là phần tử chia mảng làm 2 mảng con trái & phải */
        int p = partition(arr, low, high);
 
        // Gọi đệ quy sắp xếp 2 mảng con trái và phải
        quickSort(arr, low, p - 1);
        quickSort(arr, p + 1, high);
    }
}

int main() {
    int n;
    int a[100];
    nhap(a,n);
    xuat(a,n);
    cout<<endl;
    QuickSort(a,n);
    cout<<"Mang sau khi sap xep quicksort: "<<endl;
    xuat(a,n);
    return 0;
}