#include <iostream>
#include <cmath>
using namespace std;

void nhap(int a[], int &n) { 
    cout<<"Nhap kich thuoc mang n = "; cin>>n;
    cout<<"Nhap gia tri mang"<<endl;
    for(int i=0; i<n; i++) { 
        cin>>a[i];
    }
}

void xuat(int a[], int &n) { 
    for(int i=0; i<n; i++) { 
        cout<<" "<<a[i];
    }
}

void swap(int &x, int &y)
{
    int temp = x;
    x = y;
    y = temp;
} 

void SelectionSort(int a[], int n)
{
    int min;
    for (int i = 0; i < n - 1; i++)
    {
        min = i; // tạm thời xem a[i] là nhỏ nhất
        // Tìm phẩn tử nhỏ nhất trong đoạn từ a[i] đến a[n - 1]
        for (int j = i + 1; j < n; j++)
            if (a[j] < a[min]) // a[j] mà nhỏ hơn a[min] thì a[j] là nhỏ nhất
                min = j; // lưu lại vị trí a[min] mới vừa tìm được
        if (min != i) // nếu như a[min] không phải là a[i] ban đầu thì đổi chỗ
            swap(a[i], a[min]);
    }
}

int main() {
    int n;
    int a[100];
    nhap(a,n);
    xuat(a,n);
    cout<<endl;
    SelectionSort(a,n);
    cout<<"Mang sau khi sap xep selectionsort: "<<endl;
    xuat(a,n);
    return 0;
}